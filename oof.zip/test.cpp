#include "SFML/Graphics.hpp"
#include "SFML/Audio.hpp"
#include <iostream>
// #include "Oof.h"
using namespace sf;
int main(int argc, char ** argv) {
	// Oof oof;
	// int dam = oof.hello();
	sf::RenderWindow renderWindow(VideoMode(640, 640), "Bouncy Ball");

	sf::Event event;
	sf::Clock clock;

  Music music;
  if (!music.openFromFile("main.ogg")) {
    return -1;
  }
  music.play();

	RectangleShape square;
	square.setFillColor(Color::White);
	square.setPosition(100, 100);
	square.setSize(Vector2f(50, 50));

	int numberOfSquares = 10;
	RectangleShape squares[10];
	int squaresVelocity[numberOfSquares][2];

	for (int i = 0; i < numberOfSquares; i++) {
		srand((int)time(0) * 17 * i);
		int x = rand() % 620;
		srand((int)time(0) * 22 * i);
		int y = rand() % 620;
		srand((int)time(0) * 765 * i);
		int vx =  rand() % 500 + 100;
		srand((int)time(0) * 31 * i);
		int vy =  rand() % 500 + 100;
		if (i < 5) {
			squares[i].setFillColor(Color::Blue);
		} else {
			squares[i].setFillColor(Color::Red);
		}
		squares[i].setPosition(x, y);
		squares[i].setSize(Vector2f(20, 20));
		squaresVelocity[i][1] = vx;
		squaresVelocity[i][2] = vy;
	}

	while(renderWindow.isOpen()) {
		while (renderWindow.pollEvent(event)) {
			if (event.type == sf::Event::EventType::Closed) {
				renderWindow.close();
			}
			if (event.type == Event::KeyPressed) {
				if (event.key.code == Keyboard::Key::Escape) {
					renderWindow.close();
				}
				if (event.key.code == Keyboard::Key::C) {
					for (int i = 0; i < numberOfSquares; i++) {
						if (squares[i].getFillColor() == Color::Blue) {
							squares[i].setFillColor(Color::Red);
						} else {
							squares[i].setFillColor(Color::Blue);
						}
					}
				}
			}
		}

		Time deltaTime = clock.restart();

		for (int i = 0; i < numberOfSquares; i++) {
			if (squares[i].getPosition().x + 20 > 640 || squares[i].getPosition().x < 0) {
				squaresVelocity[i][1] *= -1;
			}

			if (squares[i].getPosition().y + 20 > 640 || squares[i].getPosition().y < 0) {
				squaresVelocity[i][2] *= -1;
			}
			squares[i].setPosition(squares[i].getPosition().x + squaresVelocity[i][1] * deltaTime.asSeconds(), squares[i].getPosition().y + squaresVelocity[i][2] * deltaTime.asSeconds());
		}


		renderWindow.clear();
		for (int i = 0; i < numberOfSquares; i++) {
			renderWindow.draw(squares[i]);
		}
		renderWindow.display();
	}

}
