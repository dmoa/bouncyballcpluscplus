class Oof{
public:
  int hello();
};
